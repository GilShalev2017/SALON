const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Customer = new Schema({
  firstName: {
    type: String
  },
  lastName: {
    type: String
  },
  phone: {
    type: String
  },
  email: {
    type: String
  },
  birthDate: {
    type: Date
  },
  address: {
    type: String
  }
}, {
  collection: 'customers'
})

module.exports = mongoose.model('Customer', Customer)