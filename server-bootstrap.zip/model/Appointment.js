const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Appointment = new Schema({
  customerId: {
    type: String
  },
  firstName: {
    type: String
  },
  lastName: {
    type: String
  },
  // date: {
  //   type: Date
  // },
  // time: {
  //   type: String
  // },
  dateString: {
    type: String
  },
  timeString: {
    type: String
  },
  treatment: {
    type: String
  },
  status: {
    type: String
  }
}, {
  collection: 'appointments'
})

module.exports = mongoose.model('Appointment', Appointment)
