// Import dependencies
const mongoose = require('mongoose');
const express = require('express');
const router = express.Router();

//const https = require('https');
//const ProxyAgent = require('proxy-agent');

// MongoDB URL from the docker-compose file
//const dbHost = 'mongodb://database/cinema-docker';

// MongoDB URL for webstorm run
const dbHost = 'mongodb://localhost:27017/edgardo-beauty-salon'

// Connect to mongodb
mongoose.connect(dbHost);

let Customer = require('../model/Customer.js');
let Appointment = require('../model/Appointment');

///////////////////////////////////// Helper Functions //////////////////////////////////
function getCurrentDateTime() {
  const date = new Date();
  let currDateTime = date.getFullYear().toString();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hour = date.getHours();
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();

  currDateTime += month < 10 ? ('-0' + month.toString()) : '-' + month.toString();
  currDateTime += day < 10 ? ('-0' + day.toString()) : '-' + day.toString();
  currDateTime += hour < 10 ? ('T0' + hour.toString()) : 'T' + hour.toString();
  currDateTime += minutes < 10 ? (':0' + minutes.toString()) : ':' + minutes.toString();
  currDateTime += seconds < 10 ? (':0' + seconds.toString()) : ':' + seconds.toString();
  return currDateTime;
}

function getOneMonthEarlierDateTime() {
  const date = new Date();
  let currDateTime = date.getFullYear().toString();
  const month = date.getMonth();
  const day = date.getDate();
  const hour = date.getHours();
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();

  currDateTime += month < 10 ? ('-0' + month.toString()) : '-' + month.toString();
  currDateTime += day < 10 ? ('-0' + day.toString()) : '-' + day.toString();
  currDateTime += hour < 10 ? ('T0' + hour.toString()) : 'T' + hour.toString();
  currDateTime += minutes < 10 ? (':0' + minutes.toString()) : ':' + minutes.toString();
  currDateTime += seconds < 10 ? (':0' + seconds.toString()) : ':' + seconds.toString();
  return currDateTime;
}

function getOneMonthLaterDateTime() {
  const date = new Date();
  let currDateTime = date.getFullYear().toString();
  const month = date.getMonth() + 2;
  const day = date.getDate();
  const hour = date.getHours();
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();

  currDateTime += month < 10 ? ('-0' + month.toString()) : '-' + month.toString();
  currDateTime += day < 10 ? ('-0' + day.toString()) : '-' + day.toString();
  currDateTime += hour < 10 ? ('T0' + hour.toString()) : 'T' + hour.toString();
  currDateTime += minutes < 10 ? (':0' + minutes.toString()) : ':' + minutes.toString();
  currDateTime += seconds < 10 ? (':0' + seconds.toString()) : ':' + seconds.toString();
  return currDateTime;
}

function getCurrentDate() {
  const date = new Date();
  let currDate = date.getFullYear().toString();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  currDate += month < 10 ? ('-0' + month.toString()) : '-' + month.toString();
  currDate += day < 10 ? ('-0' + day.toString()) : '-' + day.toString();
  return currDate;
}

function sortAppointments(appointments) {
  const sortedAppointments = appointments.sort((a, b) => {
    return (
      Date.parse(a.dateString + "T" + a.timeString) - Date.parse(b.dateString + "T" + b.timeString)
    );
  });
  return sortedAppointments;
}
/////////////////////////////////// CUSTOMER //////////////////////////////////////////////////
// Add Customer
router.route('/add-customer').post((req, res, next) => {
  console.log(req.body);
  Customer.create(req.body, (error, data) => {
    if (error) {
      console.log(error);
      return next(error)
    } else {
      console.log("Customer Added!");
      res.json(data)
    }
  })
});

// Update Customer
router.route("/update-customer").put((req, res) => {
  const customerId = req.body._id;
  console.log(`customerId=${customerId}`);
  //Customer.findById({ _id: customerId }).then((customer) => {
  //Customer.findByIdAndUpdate(req.body, (error, data) => {
  Customer.findOne({ _id: customerId }).then((customer) => {
    if (customer) {
      customer.firstName = req.body.firstName;
      customer.lastName = req.body.lastName;
      customer.email = req.body.email;
      customer.phone = req.body.phone;
      customer.birthDate = req.body.birthDate;
      customer.address = req.body.address;
      customer
        .save()
        .then(() => {
          console.log("Customer Updated!");
          res.json(customer);
        })
        .catch((err) => {
          // console.log(err);
          res.status(400).json(`Error : ${err}`);
        });
    }
  });
});

// Delete Customer
router.route('/delete-customer/:id').delete((req, res, next) => {
  const id = req.params.id;
  console.log(id);

  Customer.deleteOne({ _id: id }, (error, data) => {
    if (error) {
      return next(error)
    } else {
      res.json(data)
    }
  })
});

//Get Customer by firstName or lastname contains the attached prefix
router.route('/findCustomer/:prefix').get(async (req, res) => {
  try {
    const cutsomerPrefix = req.params.prefix;
    // console.log(cutsomerPrefix);

    //TODO improve the search to all the options
    const customersExactByFirstName = await Customer.find({ firstName: cutsomerPrefix });
    // console.log(cusomersExactByFirstName);
    const customersExactByLastName = await Customer.find({ lastName: cutsomerPrefix });
    // console.log(cusomersExactByLastName);

    // const cusomersExactByBoth = await Customer.find([{ firstName: cutsomerPrefix}, {lastName: cutsomerPrefix}]);
    // const cusomersByBothName = await Customer.find({ "firstName": `/.*{cutsomerPrefix}}.*/i`, "lastName": `/.*{cutsomerPrefix}}.*/i`});
    // console.log(cusomersByBothName);
    // const cusomersByFirstName = await Customer.find({ "firstName": `/.*{cutsomerPrefix}}.*/i`});
    // console.log(cusomersByFirstName);
    // const cusomersByLastName = await Customer.find({ "lastName": `/.*{cutsomerPrefix}}.*/i`});
    // console.log(cusomersByLastName);

    let customers = [...customersExactByFirstName, ...customersExactByLastName];
    let mergeSet = new Set();
    const unique = customers.filter(item => !mergeSet.has(JSON.stringify(item)) ? mergeSet.add(JSON.stringify(item)) : false);
    console.log(unique);


    //let customers = [...customersExactByFirstName, ...customersExactByLastName];
    //let uniqueCustomers = mergeDedupe(customers)
    // //, ...cusomersExactByBoth ];
    //let uniqueCustomers = Array.from(mergeSet);
    //let uniqueCustomers = [...new Set([...customersExactByFirstName ,...customersExactByLastName])];
    //console.log(uniqueCustomers);

    //TODO remove duplicates

    if (unique) {
      return res.status(200).json(unique);
    }
    else {
      return res.status(201).json({ message: "Customers were not found!" });
    }
  }
  catch (err) {
    console.log(err);
    res.status(400).json({ message: err });
  }
})

/////////////////////////////////// CUSTOMER TREATMENTS //////////////////////////////////////////////////

// Add Treatment - when closing appointment
router.route('/add-treatment').post((req, res, next) => {
  console.log(req.body);
  // CustomerTreatment.create(req.body, (error, data) => {
  //   if (error) {
  //     console.log(error);
  //     return next(error)
  //   } else {
  //     console.log("CustomerTreatment Added!");
  //     res.json(data)
  //   }
  // })
});

//Update Treatment

//Delete Treatment
router.route('/delete-treatment/:id').delete((req, res, next) => {
  const id = req.params.id;
  console.log(id);

  //Appointment.findByIdAndRemove({ _id: id }, (error, data) => {
  // CustomerTreatment.deleteOne({ _id: id }, (error, data) => {
  //   if (error) {
  //     return next(error)
  //   } else {
  //     res.json(data)
  //   }
  // })
});

/////////////////////////////////// APPOINTMENTS //////////////////////////////////////////////////

// Add Appointment
router.route('/add-appointment').post((req, res, next) => {
  Appointment.create(req.body, (error, data) => {
    if (error) {
      return next(error)
    } else {
      res.json(data)
    }
  })
});

router.route("/update-appointment").put((req, res) => {
  const appointmentId = req.body.id;
  console.log(`Inside update-appointment appointmentId=${appointmentId}`);
  Appointment.findOne({ _id: appointmentId }).then((appointment) => {
    if (appointment) {
      console.log("found");
      //appointment.customerId = req.body.customerId;
      //appointment.firstName = req.body.firstName;
      //appointment.lastName = req.body.lastName;
      appointment.dateString = req.body.dateString;
      appointment.timeString = req.body.timeString;
      // appointment.treatment = req.body.treatment;
      //appointment.status = req.body.status;
      appointment
        .save()
        .then(() => {
          console.log("Appointment Updated!");
          res.json(appointment);
        })
        .catch((err) => {
          console.log(err);
          res.status(400).json(`Error : ${err}`);
        });
    }
  });
 
})

// Get All Appointments - for testing purposes only
router.route('/get-all-appointments').get(async (req, res) => {
  try {
    Appointment.find((error, data) => {
      if (error) {
        return next(error)
      } else {
        res.json(data)
      }
    })
  }
  catch (err) {
    console.log(err);
    res.status(400).json({ message: err });
  }
})

router.route('/get-customer-appointments').post(async (req, res) => {
  console.log(`req.body=${req.body}`);
  const customerId = req.body.customerId;
  console.log(`customerId=${customerId}`);
  try {
    Appointment.find({ customerId: customerId }, (error, data) => {
      if (error) {
        return next(error)
      } else {
        res.json(data)
      }
    })
  }
  catch (err) {
    console.log(err);
    res.status(400).json({ message: err });
  }
})

// Get All Appointments by date range (one or more)
router.route('/get-all-appointments-by-date').post(async (req, res) => {
  const startingDate = new Date(2022, 7, 1); //in Date ctor:year-month-day  in DB: year-day-month !!!
  const endDate = new Date(2022, 7, 30);

  try {
    Appointment.find({ date: { $gte: startingDate, $lte: endDate } }, (error, data) => {
      if (error) {
        return next(error)
      } else {
        console.log(`get-all-appointments-by-date +${data}`)
        res.json(data)
      }
    })
  }
  catch (err) {
    console.log(err);
    res.status(400).json({ message: err });
  }
})

// Get All Opened Appointments for a customer
router.route('/get-opened-appointments').post(async (req, res) => {
  console.log(req.body);
  const customerId = req.body.customerId;
  console.log(`customerId=${customerId}`);
  try {
    Appointment.find({ status: 'Open', customerId: customerId }, (error, data) => {
      if (error) {
        return next(error)
      } else {

        const appointments = data;
        //TODO is the next time sorting correct?
        const sortedAppointments = appointments.sort((a, b) => {
          return (
            Date.parse(a.dateString + "T" + a.timeString) - Date.parse(b.dateString + "T" + b.timeString)
          );
        });

        res.json(data)
      }
    })
  }
  catch (err) {
    console.log(err);
    res.status(400).json({ message: err });
  }
})

// Delete Appointment
router.route('/delete-appointment/:id').delete((req, res, next) => {
  const id = req.params.id;
  console.log(id);

  //Appointment.findByIdAndRemove({ _id: id }, (error, data) => {
  Appointment.deleteOne({ _id: id }, (error, data) => {
    if (error) {
      return next(error)
    } else {
      res.json(data)
    }
  })
});

// Get Todays Appointments
router.route('/todays-appointments').get(async (req, res) => {
  // const date = new Date()
  // let currDate = date.getFullYear().toString()
  // const month = date.getMonth() + 1
  // const day = date.getDate()
  // currDate += month < 10 ? ('-0' + month.toString()) : '-' + month.toString()
  // currDate += day < 10 ? ('-0' + day.toString()) : '-' + day.toString()

  const currDate = getCurrentDate();

  try {

    Appointment.find({ dateString: currDate }, (error, data) => {
      if (error) {
        return next(error)
      } else {

        const appointments = data;
        //TODO is the next time sorting correct?
        const sortedAppointments = sortAppointments(appointments);
        // const sortedAppointments = appointments.sort((a, b) => {
        //   return (
        //     Date.parse(a.dateString + "T" + a.timeString) - Date.parse(b.dateString + "T" + b.timeString)
        //   );
        // });
        console.log(sortedAppointments);
        res.json(sortedAppointments)
      }
    })
  }
  catch (err) {
    console.log(err);
    res.status(400).json({ message: err });
  }
})

//Get upcoming appointments
router.route('/upcoming-appointments').post(async (req, res) => {
  const customerId = req.body.customerId;
  try {
    Appointment.find({ customerId: customerId }, (error, data) => {
      if (error) {
        return next(error)
      } else {
        const appointments = data;
        const currDateTime = getCurrentDateTime();
        const filteredAppointments = appointments.filter((appointment) => {
          // const elementA = Date.parse(currDateTime);
          // const elementB = Date.parse(appointment.dateString + 'T' + appointment.timeString);
          return Date.parse(currDateTime) <= Date.parse(appointment.dateString + 'T' + appointment.timeString)
        })
        //console.log(`filteredAppointments=${filteredAppointments}`);
        const sortedAppointments = sortAppointments(filteredAppointments);
        //console.log(sortedAppointments);
        res.status(200).json(sortedAppointments)
      }
    })
  }
  catch (err) {
    console.log(err);
    res.status(400).json({ message: err });
  }
})

//Get previous appointments
router.route('/previous-appointments').post(async (req, res) => {
  const customerId = req.body.customerId;
  console.log(`customerId=${customerId}`);
  console.log(`Inside previous-appointments`);
  try {
    Appointment.find({ customerId: customerId }, (error, data) => {
      if (error) {
        return next(error)
      } else {
        const appointments = data;
        const currDateTime = getCurrentDateTime();
        const filteredAppointments = appointments.filter((appointment) => {
          return Date.parse(currDateTime) >= Date.parse(appointment.dateString + 'T' + appointment.timeString)
        })
        //        console.log(`filteredAppointments=${filteredAppointments}`);
        const sortedAppointments = sortAppointments(filteredAppointments);
        //      console.log(sortedAppointments);
        res.status(200).json(sortedAppointments)
      }
    })
  }
  catch (err) {
    console.log(err);
    res.status(400).json({ message: err });
  }
})

// Get Appointments by date range (one or more)
router.route('/get-appointments-by-range').get(async (req, res) => {

  try {
    Appointment.find((error, data) => {
      if (error) {
        return next(error)
      } else {
        const appointments = data;
        const filteredAppointments = appointments.filter((appointment) => {
          const oneMonthEarlierDate = Date.parse(getOneMonthEarlierDateTime());
          const oneMontheLaterDate = Date.parse(getOneMonthLaterDateTime());
          const currAppointmentDateTime = Date.parse(appointment.dateString + 'T' + appointment.timeString);

          return currAppointmentDateTime <= oneMontheLaterDate && currAppointmentDateTime >= oneMonthEarlierDate;
        })
        //console.log(`filteredAppointments=${filteredAppointments}`);
        const sortedAppointments = sortAppointments(filteredAppointments);
        //console.log(sortedAppointments);
        res.status(200).json(sortedAppointments)
      }
    })
  }
  catch (err) {
    console.log(err);
    res.status(400).json({ message: err });
  }
})

module.exports = router;


// // // Get Appointments by date range (one day or more)
// // router.route('/get-all-appointments-by-date').get(async (req, res) => {
// //   const startingDate = new Date(2026, 1, 2); //in Date ctor:year-month-day  in DB: year-day-month !!!
// //   const endDate = new Date(2026, 1, 2);

// //   try {
// //     Appointment.find({ date: { $gte: startingDate, $lte: endDate }},(error, data) => {
// //       if (error) {
// //         return next(error)
// //       } else {
// //         res.json(data)
// //       }
// //     })
// //   }
// //   catch (err) {
// //     console.log(err);
// //     res.status(400).json({ message: err });
// //   }
// // })




// // Get Todays Appointments
// router.route('/get-todays-schedule').get(async (req, res) => {
//   //const today = new Date(2022, 10, 7);
//   //console.log(today);
//   // const utcDay = today.getUTCDate();
//   // const utcMonth = today.getUTCMonth();
//   // const utcYear = today.getUTCFullYear();

//   //const gilsDate = new Date(2022, 1, 2);
//   const gilsDate = new Date(2025, 5, 4);
//   const result = await Appointment.find({ date: { $gte: gilsDate, $lte: gilsDate } }) //dates + firstName + lastName
//   console.log(`2025, 5, 4 ${result}`);

//   //Summary:
//   //In the UI we set to: "05-05-2025"
//   //In the DB it changes to 2025-05-04T21:00:00.000+00:00 as a date not a string
//   //Here in Node.js new Date() we should swap day & month to Date(2025,4,5)
//   //Consider: using string instead of a date, but maybe date range won't work!
//   //Pay attention to ISO/UTC/Local...
//   //Date time - different types now - what is recommended?

//   try {

//     // const composedToday = new Date(utcYear, utcMonth, utcDay);
//     // console.log(composedToday);
//     console.log("LATEST");
//     const todayDate = new Date();
//     console.log(`todayDate=${todayDate}`);
//     const year = todayDate.getUTCFullYear();
//     console.log(`year=${year}`)
//     const month = todayDate.getUTCMonth();
//     console.log(`month=${month}`)
//     const day = todayDate.getUTCDate();
//     console.log(`day=${day}`);
//     const todayDateFix = new Date(year, day, month);
//     console.log(`todayDateFix=${todayDateFix}`);
//     const todayDateFixString = `${year}-${month}-${day}`;
//     console.log(`todayDateFixString=${todayDateFixString}`);

//     const resultLatest = await Appointment.find({ date: { $gte: todayDateFixString, $lte: todayDateFixString } }) //dates + firstName + lastName
//     console.log(resultLatest);

//     console.log("inside get-todays-schedule");
//     const startingDate = new Date(2022, 1, 2);
//     const result2 = await Appointment.find({ date: { $gte: startingDate, $lte: startingDate } }) //dates + firstName + lastName
//     console.log(result2);

//     const startingDate2 = new Date(2025, 4, 5);
//     const result3 = await Appointment.find({ date: { $gte: startingDate2, $lte: startingDate2 } }) //dates + firstName + lastName
//     console.log(`2025, 4, 5 ${result3}`);

//     Appointment.find({ date: { $gte: gilsDate, $lte: gilsDate } }, (error, data) => {
//       if (error) {
//         return next(error)
//       } else {
//         console.log(data);
//         res.json(data)
//       }
//     })
//   }
//   catch (err) {
//     console.log(err);
//     res.status(400).json({ message: err });
//   }
// })



// // Get All Appointments by date range and customerId (one or more)
// router.route('/get-all-appointments-by-multiple').get(async (req, res) => {
//   const startingDate = new Date(2022, 1, 2); //in Date ctor:year-month-day  in DB: year-day-month !!!
//   const endDate = new Date(2022, 1, 2);
//   const customerId = '62c9f5df0e2161450e6b0ae1';
//   console.log("inside get-all-appointments-by-multiple");
//   //maybe use customerId instead of firstName+lastName
//   const result = await Appointment.find({ date: { $gte: startingDate, $lte: endDate }, firstName: 'Gil', lastName: 'Shalev' }) //dates + firstName + lastName
//   console.log(result);
// })