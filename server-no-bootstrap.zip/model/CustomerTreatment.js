const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let CustomerTreatment = new Schema({
  customerId: {
    type: String
  },
  firstName: {
    type: String
  },
  lastName: {
    type: String
  },
  date: {
    type: Date
  },
  treatment: {
    type: String
  }
}, {
  collection: 'customerTreatments'
})

module.exports = mongoose.model('CustomerTreatment',CustomerTreatment)