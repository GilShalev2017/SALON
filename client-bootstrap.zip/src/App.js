import './App.css';
import "bootstrap";
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap.js";
import "bootstrap/dist/css/bootstrap.min.css";
import SearchCustomer from './components/SearchCustomer/SearchCustomer';
import NewBookAppointment from './components/NewBookAppointment/NewBookAppointment';
import AddNewCustomer from './components/AddNewCustomer/AddNewCustomer';
import CloseAppointment from './components/CloseAppointment/CloseAppointment';
import CustomerDetails from './components/CustomerDetails/CustomerDetails';
import CustomerTicket from './components/CustomerTicket/CustomerTicket';
import SaloonSchedule from './components/SaloonSchedule/SaloonSchedule';
import Header from './components/Header/Header';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div className="wrapper">
  
      <h2>Select one of the options:</h2>
      <nav>
        <ul>
          <li><a href="/search-customer">Search a Customer</a></li>
          <li><a href="/add-new-customer">Add a new Customer</a></li>
          <li><a href="/saloon-schedule">Saloon's Schedule</a></li>
        </ul>
      </nav>
      <BrowserRouter>
        <Routes>
          {/* <Route path="/" element={<SearchCustomer/>}></Route> */}
          <Route path="/search-customer" element={<SearchCustomer />}></Route>
          <Route path="/new-book-appointment" element={<NewBookAppointment />}></Route>
          <Route path="/customer-details" element={<CustomerDetails />}></Route>
          <Route path="/add-new-customer" element={<AddNewCustomer />}></Route>
          <Route path="/customer-ticket" element={<CustomerTicket />}></Route>
          <Route path="/close-appointment" element={<CloseAppointment />}></Route>
          <Route path="/saloon-schedule" element={<SaloonSchedule />}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
