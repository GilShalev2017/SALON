import React, { useState, useEffect } from "react";
import Axios from "axios";
import { Link } from 'react-router-dom';
import {
    Row,
    Col,
    Input,
    Button,
    InputGroup,
} from "reactstrap";
import Scrollbar from "react-scrollbars-custom";

function SearchCustomer() {
    const [customers, setCustomers] = useState([]);
    const [text, setText] = useState('');

    const fetchCustomers = () => {
        Axios.get(`http://localhost:3000/findCustomer/${text}`).then(response => {
            setCustomers(Array.from(response.data));
            console.log(customers);
        });
    };

    function onTextChanged(e) {
        let value = e.target.value;
        setText(value);
    }

    return (
        <div>
            <Row className="mb-3 mx-auto" style={{ width: "500px" }}>
                <Col>
                    <InputGroup>
                        <Input
                            value={text}
                            type="text"
                            placeholder="Search a Customer"
                            onChange={onTextChanged}
                            className="mb-1"
                        />
                        <div style={{ height: 10 }} className="">
                            <Button
                                className="h-10 d-inline-block"
                                color="primary"
                                onClick={fetchCustomers}>
                                Search
                            </Button>
                        </div>
                    </InputGroup>
                    {/* {renderSuggestions()} */}
                </Col>
            </Row>
            <div className="row mb-3 mx-auto">
                {
                    customers.map((customer) => (
                        <div className="col-sm-6 mb-2 mx-auto" key={customer._id}>
                         {/* <div className="col-sm-4" key={customer._id}> */}
                            <div className="card">
                                <div className="card-body">
                                    <div className="text-info">
                                        <h6>
                                            Name: <span> {customer.firstName} {customer.lastName}</span>
                                        </h6>
                                    </div>
                                    <div>Phone Number : {customer.phone}</div>
                                    <div>Email: {customer.email}</div>
                                    <div>Address: {customer.address}</div>
                                    {/* <div className="col align-self-end col-md-6" style={{ textAlign: "center", marginTop: "10px" }}> */}
                                    <div className="col align-self-end col-md-12" style={{ float: "right", marginTop: "10px" }}>
                                        <Link to="/customer-ticket" state={{ from: customer }}>
                                            <button className="btn btn-sm btn-primary">Go To Customer Card</button>
                                        </Link>
                                        <Link to="/new-book-appointment" state={{ from: customer }} style={{ marginLeft: "20px" }}>
                                            <button className="btn btn-sm btn-primary">Book an Appointment</button>
                                        </Link>
                                    </div>

                                </div>
                            </div>
                        </div>
                    ))}
            </div>
        </div >
    );
}

export default SearchCustomer;