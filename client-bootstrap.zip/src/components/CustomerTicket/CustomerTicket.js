import { useLocation } from 'react-router-dom'
import CustomerDetails from '../CustomerDetails/CustomerDetails';
import { Link } from 'react-router-dom';
import {
    Button,
} from "reactstrap";

function CustomerTicket(props) {
    const location = useLocation();
    const { from } = location?.state;
    console.log(from);
    return (
        <div style={{ textAlign: "center" }}>
            <CustomerDetails customer={from} />
           
            <div>
                <Link to="/new-book-appointment" state={{ from: from }}>
                    <Button>Book an appointment</Button>
                </Link>
            </div>

        </div>
    );
}

export default CustomerTicket;