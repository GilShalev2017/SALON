import React, {  useEffect } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import "@fullcalendar/daygrid/main.css";
import "@fullcalendar/timegrid/main.css";
import interactionPlugin from "@fullcalendar/interaction";
import events from "./events";

function MonthSchedule(props) {
    const calendarRef = React.createRef();

    const view = calendarRef.view;

    function handleDateClick() {
        calendarRef.changeView('timeGridDay');

        // this.calendarRef.current
        //     .getApi()
        //     .changeView('dayGridDay', dateClickInfo.date)
    };

    // useEffect(() => {
    //     alert("The view's title is " + view.title);
    // }, []);

    return (
        <div className="App">
            <FullCalendar
                defaultView="dayGridWeek" //dayGridWeek whould turn into dayGridWeek, but display dayGridMonth instead
                editable={true}
                headerToolbar={{
                    left: "prev,next",
                    center: "title",
                    right: "dayGridMonth,timeGridWeek,timeGridDay"
                }}
                dateClick={handleDateClick}
                themeSystem="Simplex"
                plugins={[dayGridPlugin, interactionPlugin]}
                events={events}
            />
            <FullCalendar
                defaultView="dayGridWeek"
                editable={true}
                // themeSystem="Simplex"
                // header={{
                //   left: "prev,next",
                //   center: "title",
                //   right: "dayGridMonth,timeGridWeek,timeGridDay",
                // }}
                plugins={[dayGridPlugin, interactionPlugin]}
                events={events}
                displayEventEnd="true"
                eventColor={"#" + Math.floor(Math.random() * 16777215).toString(16)}
            />
        </div>
    );
}

export default MonthSchedule;