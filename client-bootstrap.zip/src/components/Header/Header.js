import { React, useState } from 'react';
import { NavLink } from 'react-router-dom';
import NavigationItem from '../NavigationItem/NavigationItem';
import { Routes } from '../../constants/routes';
import './Header.css';

function Header(props) {
    const [link, setLink] = useState(Routes.SERVICES_FOR_MEN);

    const handlerClick = (e) => {
        e.persist();
        console.log(e.target.attributes[0].value);
        this.setState({ link: e.target.attributes[0].value });
    };

    // handleClick(e) {
    //     this.saySomething("element clicked");
    // }
    return (
        <header className="container">
            <nav className="nav">
                <ul className="nav__items d-flex">
                    <NavigationItem link={Routes.MAIN} exact>
                        Home
                    </NavigationItem>
                    <li className="nav__item nav__item--submenu">
                        <NavLink to={link} activeClassName="active">
                            Services
                        </NavLink>
                        <ul className="nav__submenu">
                            <NavigationItem
                                link={Routes.SERVICES_FOR_MEN}
                                submenu
                                clickHandler={(e) => this.handlerClick(e)}
                            >
                                for men
                            </NavigationItem>
                            <NavigationItem
                                link={Routes.SERVICES_FOR_WOMEN}
                                submenu
                                clickHandler={(e) => this.handlerClick(e)}
                            >
                                for women
                            </NavigationItem>
                        </ul>
                    </li>

                    <li className="nav__item nav__item--submenu">
                        <NavLink to={link} activeClassName="active"> 
                            Client Tickets
                        </NavLink>
                        <ul className="nav__submenu">
                            <NavigationItem
                                link={Routes.FIND_A_TICKET}
                                submenu
                                clickHandler={(e) => this.handlerClick(e)}
                            >
                                find a Ticket
                            </NavigationItem>
                            <NavigationItem
                                link={Routes.ADD_A_TICKET}
                                submenu
                                clickHandler={(e) => this.handlerClick(e)}
                            >
                                Add a Ticket
                            </NavigationItem>
                        </ul>
                    </li>

                    {props.isAuthenticated ? (
                        <NavigationItem link={Routes.TICKETS}>Client Tickets</NavigationItem>
                    ) : null}
                    {props.isAuthenticated ? (
                        <NavigationItem link={Routes.ACCOUNT}>My account</NavigationItem>
                    ) : null}
                    {props.isAuthenticated ? (
                        <NavigationItem link={Routes.SIGNOUT}>Sign out</NavigationItem>
                    ) : (
                        <NavigationItem link={Routes.SIGNIN}>Sign in</NavigationItem>
                    )}
                    {!props.isAuthenticated && (
                        <NavigationItem link={Routes.SIGNUP}>Sign up</NavigationItem>
                    )}
                </ul>
            </nav>
        </header>
    );
}

export default Header;