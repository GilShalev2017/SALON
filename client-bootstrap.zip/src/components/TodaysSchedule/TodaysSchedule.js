import React, { useState, useEffect } from "react";
import Axios from "axios";
import Moment from 'moment';

function TodaysSchedule() {
    const [appointments, setAppointments] = useState([]);
    
    useEffect(() => {
        fetchTodaysSchedule();
    }, []);

    const fetchTodaysSchedule = () => {
        Axios.get('http://localhost:3000/todays-appointments')
            .then(response => {
                setAppointments(Array.from(response.data));
                console.log(appointments);
            })
            .catch(error => {
                console.log(error);
            })
    };

    return (
        <div>
            <table className="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Time</th>
                        <th scope="col">Name</th>
                        <th scope="col">Treatment</th>
                    </tr>
                </thead>
                <tbody>
                    {appointments.map((appointment) => (
                        <tr key={appointment._id}>
                            {/* <th scope="row">{appointment.dateString}</th> */}
                            <th scope="row">{Moment(appointment.dateString).format('DD/MM')}</th>
                            <th scope="row">{appointment.timeString}</th>
                            {/* {new Intl.DateTimeFormat("en-GB").format(appointment.timeString)} */}
                            {/* <th scope="row">{Moment(appointment.timeString).format('LLLL')}</th> */}
                            <th scope="row">{appointment.firstName} {appointment.lastName}</th>
                            <th scope="row">{appointment.treatment}</th>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default TodaysSchedule;