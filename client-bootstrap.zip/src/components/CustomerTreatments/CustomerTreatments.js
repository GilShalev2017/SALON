import React, { useState, useEffect } from "react";
import Axios from "axios";
import { BsPencilSquare } from "react-icons/bs";

function CustomerTreatments(props) {
    const [id, setId] = useState(props.customer._id);
    const [firstName, setFirstName] = useState(props.customer.firstName);
    const [lastName, setLastName] = useState(props.customer.lastName);

    const [treatments, setTreatments] = useState([]);
    const [futureAppointments, setFutureAppointments] = useState([]);
    const [previousAppointments, setPreviousAppointments] = useState([]);

    useEffect(() => {
        fetchCustomerAppointments();
    }, []);

    const fetchCustomerAppointments = () => {

        // Axios.post('http://localhost:3000/get-customer-appointments',
        Axios.post('http://localhost:3000/previous-appointments',
        //  Axios.post('http://localhost:3000/get-opened-appointments', 
        {
            customerId: id
        })
        .then(response => {
            const previousAppointments = (Array.from(response.data));
            setPreviousAppointments(previousAppointments);
            console.log(previousAppointments);
        })
        .catch(error => {
            console.log(error);
        })

        Axios.post('http://localhost:3000/upcoming-appointments',
        {
            customerId: id
        })
        .then(response => {
            const futureAppointments = (Array.from(response.data));
            setFutureAppointments(futureAppointments);
            console.log(futureAppointments);
        })
        .catch(error => {
            console.log(error);
        })
    };

    function addTreatment() {
        Axios.post('http://localhost:3000/add-treatment',
            {
                customerId: id,
                firstName: firstName,
                lastName: lastName,
                date: "05-05-2025",
                treatment: 'coloring and dying'
            })
            .then(response => {
                console.log(response);
                //addTreatment(response);
            })
            .catch(error => {
                console.log(error);
            })
    }

    return (
        <div style={{ textAlign: "center" }}  className="col-sm-6 mb-2 mx-auto">
            
            {/* <button onClick={addTreatment}>Add Treatment</button> */}


            <h6>Past Appointments</h6>
            <table className="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Time</th>
                        <th scope="col">Treatment</th>
                    </tr>
                </thead>
                <tbody>
                    {previousAppointments.map((previousAppointment) => (
                        <tr key={previousAppointment._id}>
                            <th scope="row">{previousAppointment.dateString}</th>
                            <th scope="row">{previousAppointment.timeString}</th>
                            <th scope="row">{previousAppointment.treatment}</th>
                        </tr>
                    ))}
                </tbody>
            </table>
            <h6>Future Appointments</h6>
            <table className="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Time</th>
                        <th scope="col">Treatment</th>
                    </tr>
                </thead>
                <tbody>
                    {futureAppointments.map((futureAppointment) => (
                        <tr key={futureAppointment._id}>
                            <th scope="row">{futureAppointment.dateString}</th>
                            <th scope="row">{futureAppointment.timeString}</th>
                            <th scope="row"><BsPencilSquare/></th>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default CustomerTreatments;