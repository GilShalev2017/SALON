import React, { useState, useEffect } from "react";
import Axios from "axios";
import { Link } from 'react-router-dom';
import {Row, Button, Input} from "reactstrap";

function AddNewCustomer() {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [address, setAddress] = useState('');
    const [birthdate, setBirthdate] = useState(0);

    const [newCustomer, setNewCustomer] = useState(null);

    function cleanCustomerFields(){
        setFirstName('');
        setLastName('');
        setPhone('');
        setEmail('');
        setAddress('');
        setBirthdate('');
    }

    function saveCustomer() {
        Axios.post('http://localhost:3000/add-customer',
            {
                firstName: firstName,
                lastName: lastName,
                phone: phone,
                email: email,
                birthDate: birthdate,
                address: address
            })
            .then(response => {
                console.log(response);
                setNewCustomer(response);
                cleanCustomerFields();
            })
            .catch(error => {
                console.log(error);
            })
    }

    return (
        <div>
            <div style={{ textAlign: "center" }} className="col-sm-3 mb-2 mx-auto">
                <h3>Add New Customer</h3>
                <div>
                    <img src="https://media-exp2.licdn.com/dms/image/C4D03AQHTLgbwEQjOhg/profile-displayphoto-shrink_100_100/0/1517457003952?e=1662595200&v=beta&t=bGIJZo80g_oPkMscF5M5LiGJXR9P00mx5C_ZdVMHtX4" />
                </div>
                <Row className="m-3"><Input placeholder="Fill customer's first name" onChange={(e) => setFirstName(e.target.value)} /></Row>
                <Row className="m-3"><Input placeholder="Fill customer's last name" onChange={(e) => setLastName(e.target.value)} /></Row>
                <Row className="m-3"><Input placeholder="Fill customer's phone number" onChange={(e) => setPhone(e.target.value)} /></Row>
                <Row className="m-3"><Input placeholder="Fill customer's email" onChange={(e) => setEmail(e.target.value)} /></Row>
                <Row className="m-3"><Input placeholder="Fill customer's address" onChange={(e) => setAddress(e.target.value)} /></Row>
                <Row className="m-3"><Input placeholder="Fill customer's birthday" type="date" onChange={(e) => setBirthdate(e.target.value)} /></Row>
                <Row className="m-3"><Button onClick={saveCustomer}>Save Customer Details</Button></Row>
                {/* Enable only if new customer has been saved */}
                <Row className="m-3">
                    {newCustomer && <Link to="/new-book-appointment" customer={newCustomer}>
                        <Button>Book an appointment</Button>
                    </Link>}
                </Row>
            </div>
        </div>
    );
}

export default AddNewCustomer;