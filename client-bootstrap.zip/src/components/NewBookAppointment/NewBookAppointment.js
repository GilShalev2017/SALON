import ReactDOM from "react-dom";
import { Col, Row } from "reactstrap";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin, { Draggable } from "@fullcalendar/interaction";
import Alert from "sweetalert2";
import "@fullcalendar/daygrid/main.css";
import "@fullcalendar/timegrid/main.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "./NewBookAppointment.css";
import React, { useState, useEffect, useRef } from "react";
import { useLocation, Link } from 'react-router-dom'
import Axios from "axios";

function NewBookAppointment(props) {

    const [events, setEvents] = useState([
        { title: "Woman Cut", id: "1" },
        { title: "Man Cut", id: "2" },
        { title: "Girl Cut", id: "3" },
        { title: "Boy Cut", id: "4" },
        { title: "Frame Cut", id: "5" },
        { title: "Keratin Treatment", id: "6" },
        { title: "Color", id: "7" },
        { title: "Heigh-lights", id: "8" },
        { title: "Up do", id: "9" }
    ]);
    const calendarRef = useRef(null);
    const [activeView, setActiveView] = useState("timeGridWeek");
    const [appointments, setAppointments] = useState([]);
    let eventGuid = 0
    function createEventId() {
        return String(eventGuid++)
    }
    const fetchRangedSchedule = (API) => {
        Axios.get('http://localhost:3000/get-appointments-by-range')
            .then(response => {
                response.data.forEach(appointment => {
                    const tmpEvent = {
                        id: appointment._id,
                        customerId: appointment.customerId,
                        title: appointment.treatment,
                        start: appointment.dateString + 'T' + appointment.timeString   //08:00:00'
                    }
                    API.addEvent(tmpEvent);
                });
                // setAppointments(Array.from(response.data));
                setAppointments(response.data);
                console.log(`appointments=${appointments}`);
            })
            .catch(error => {
                console.log(error);
            })
    };

    useEffect(() => {
        console.log("View Changed", activeView);
        const { current: calendarDom } = calendarRef;
        const API = calendarDom ? calendarDom.getApi() : null;
        API && API.changeView(activeView);
        fetchRangedSchedule(API);
        let draggableEl = document.getElementById("external-events");
        new Draggable(draggableEl, {
            itemSelector: ".fc-event",
            eventData: function (eventEl) {
                let title = eventEl.getAttribute("title");
                let id = eventEl.getAttribute("data");
                return {
                    title: title,
                    id: id
                };
            }
        });
    }, [activeView]);

    const location = useLocation();
    const { from } = location?.state;

    function getCurrentDate(info) {
        const date = new Date(info.event.start.toString());
        let currDate = date.getFullYear().toString()
        const month = date.getMonth() + 1
        const day = date.getDate()
        currDate += month < 10 ? ('-0' + month.toString()) : '-' + month.toString()
        currDate += day < 10 ? ('-0' + day.toString()) : '-' + day.toString()
        return currDate;
    }

    function getCurrentTime(info) {
        const date = new Date(info.event.start.toString());
        let hour = date.getHours();
        if (hour < 10) {
            hour = `0${hour}`;
        }
        let minute = date.getMinutes();
        if (minute < 10) {
            minute = `0${minute}`;
        }
        const currentTime = `${hour}:${minute}`;
        return currentTime;
    }

    function addAppointment(info) {
        const dateString = getCurrentDate(info);
        const timeString = getCurrentTime(info);
        
        Axios.post('http://localhost:3000/add-appointment',
            {
                customerId: from._id,
                firstName: from.firstName,
                lastName: from.lastName,
                dateString: dateString,
                timeString: timeString,
                treatment: info.event.title,
                status: "Open"
            })
            .then(response => {
                console.log(response);
                // toast("Appointment booked successfully", {
                //     type: "success"
                // })
            })
            .catch(error => {
                console.log(error);
            })
    }

    function updateAppointment(info) {
        const dateString = getCurrentDate(info);
        const timeString = getCurrentTime(info);
        Axios.put('http://localhost:3000/update-appointment',
            {
                id: info.event.id,
                dateString: dateString,
                timeString: timeString
            })
            .then(response => {
                console.log(response);
                // toast("Appointment booked successfully", {
                //     type: "success"
                // })
            })
            .catch(error => {
                console.log(error);
            })
    }

    const eventClick = eventClick => {
        Alert.fire({
            // title: eventClick.event.title,
            //     html:
            //         `<div class="table-responsive">
            //   <table class="table">
            //   <tbody>
            //   <tr >
            //   <td>Title</td>
            //   <td><strong>` +
            //         eventClick.event.title +
            //         `</strong></td>
            //   </tr>
            //   <tr >
            //   <td>Start Time</td>
            //   <td><strong>
            //   ` +
            //         eventClick.event.start +
            //         `
            //   </strong></td>
            //   </tr>
            //   </tbody>
            //   </table>
            //   </div>`,
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Remove Event",
            cancelButtonText: "Close"
        }).then(result => {
            if (result.value) {
                eventClick.event.remove(); // It will remove event from the calendar
                Alert.fire("Deleted!", "Your Event has been deleted.", "success");
            }
        });
    };

    const handleEventReceive= (info) => {
        alert(info.event.title + " was received on " + info.event.start.toString());
        addAppointment(info);
    }
    const handleDropEvent = (info) => {
        alert(info.event.title + " was dropped on " + info.event.start.toString());
        updateAppointment(info);
        // if (!confirm("Are you sure about this change?")) {
        //     info.revert();
        // }
    }
    const handleResizeEvent = (info) => {
        alert(info.event.title + " was Resized on " + info.event.start.toString() + "event=" + info.event.id.toString());
        updateAppointment();
    }

    return (
        <div className="animated fadeIn p-4 demo-app">
            <Row>
                <Col lg={2} sm={2} md={2}>
                    <div id="external-events"
                        style={{
                            marginTop:"80px",
                            padding: "10px",
                            width: "80%",
                            height: "auto",
                            maxHeight: "-webkit-fill-available"
                        }}>
                        <p align="center">
                            <strong> Treatments</strong>
                        </p>
                        {events.map(event => (
                            <div
                                className="fc-event"
                                title={`${from.firstName} ${from.lastName} ${event.title}`}
                                data={event.id}
                                key={event.id}>
                                {event.title}
                            </div>
                        ))}
                    </div>
                </Col>

                <Col lg={10} sm={10} md={10}>
                    <div style={{ textAlign: "center" }}>
                        <h3>Booking {from.firstName} {from.lastName}</h3>
                        <FullCalendar
                            plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
                            editable={true}
                            durationEditable={true}
                            eventDurationEditable={true}
                            eventResizableFromStart={true}
                            defaultView="dayGridMonth"
                            headerToolbar={{
                                left: "myPreviousButton, myNextButton",
                                center: "title",
                                right: "timeGridDay,timeGridWeek,dayGridMonth,listWeek" 
                            }}
                            customButtons={{
                                myPreviousButton: {
                                    text: "<<",
                                    click: function () {
                                        let calendarApi = calendarRef.current.getApi();
                                        calendarApi.prev();
                                    }
                                },
                                myNextButton: {
                                    text: ">>",
                                    click: function () {
                                        let calendarApi = calendarRef.current.getApi();
                                        calendarApi.next();
                                    }
                                }
                            }}
                            initialView="timeGridWeek"
                            weekends={true}
                            rerenderDelay={10}
                            droppable={true}
                            ref={calendarRef}
                            events={events}
                            // eventClick={eventClick}
                            eventReceive={handleEventReceive}
                            //eventDragStop={handleEventReceive}
                            eventDrop={handleDropEvent}
                            eventResizeStop={handleResizeEvent}
                        />
                    </div>
                </Col>
            </Row>
        </div>
    );
}

export default NewBookAppointment;