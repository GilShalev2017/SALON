import React, { useState, useEffect, useRef } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import './SaloonSchedule.css';
import Axios from "axios";

const SaloonSchedule = ({ onDateChange }) => {
    const [activeView, setActiveView] = useState("timeGridDay");
    const calendarRef = useRef(null);
    const [appointments, setAppointments] = useState([]);
    let eventGuid = 0
    //const [events, setEvents] = useState([]);

    function getCurrentDate(info) {
        const date = new Date(info.event.start.toString());
        let currDate = date.getFullYear().toString()
        const month = date.getMonth() + 1
        const day = date.getDate()
        currDate += month < 10 ? ('-0' + month.toString()) : '-' + month.toString()
        currDate += day < 10 ? ('-0' + day.toString()) : '-' + day.toString()
        return currDate;
    }

    function getCurrentTime(info) {
        const date = new Date(info.event.start.toString());
        let hour = date.getHours();
        if (hour < 10) {
            hour = `0${hour}`;
        }
        let minute = date.getMinutes();
        if (minute < 10) {
            minute = `0${minute}`;
        }
        const currentTime = `${hour}:${minute}`;
        return currentTime;
    }

    function updateAppointment(info) {
        const dateString = getCurrentDate(info);
        const timeString = getCurrentTime(info);
        Axios.put('http://localhost:3000/update-appointment',
            {
                id: info.event.id,
                dateString: dateString,
                timeString: timeString
            })
            .then(response => {
                console.log(response);
                // toast("Appointment booked successfully", {
                //     type: "success"
                // })
            })
            .catch(error => {
                console.log(error);
            })
    }

    const handleDropEvent = (info) => {
        // alert(info.event.title + " was dropped on " + info.event.start.toString());
        updateAppointment(info);
    }
    const handleResizeEvent = (info) => {
        // alert(info.event.title + " was Resized on " + info.event.start.toString() );
        updateAppointment(info);
    }
    // function createEventId() {
    //     return String(eventGuid++)
    // }

    const fetchRangedSchedule = (API) => {
        Axios.get('http://localhost:3000/get-appointments-by-range')
            .then(response => {
                response.data.forEach(appointment => {
                    const tmpEvent = {
                        id: appointment._id,
                        customerId: appointment.customerId,
                        title: appointment.treatment,
                        start: appointment.dateString + 'T' + appointment.timeString   //08:00:00'
                    }
                    API.addEvent(tmpEvent);
                });
                // setAppointments(Array.from(response.data));
                setAppointments(response.data);
                console.log(`appointments=${appointments}`);
            })
            .catch(error => {
                console.log(error);
            })
    };

    useEffect(() => {
        console.log("View Changed", activeView);
        const { current: calendarDom } = calendarRef;
        const API = calendarDom ? calendarDom.getApi() : null;
        API && API.changeView(activeView);
        fetchRangedSchedule(API);
        // API.addEvent({
        //     id: 9999,
        //     title: 'Steve Jobs event',
        //     start: '2022-07-14' + 'T18:00:00'
        // });
    }, [activeView]);

    function renderEventContent(eventInfo) {
        return (
            <>
                <b>{eventInfo.timeText}</b>
                <i>{eventInfo.event.title}</i>
            </>
        );
        // if (activeView === 'dayGridMonth') {
        //     return (
        //         <>
        //             <b>{eventInfo.timeText}</b>
        //             <i>{eventInfo.event.title}</i>
        //         </>
        //     );
        // }
        // else {
        //     return (
        //         <>
        //             <i>{eventInfo.event.title}</i>
        //         </>
        //     );
        // }
    }

    return (
        <div>
            <div className="demo-app-main">
                <br></br>
                <FullCalendar className="fullCalendar"
                    plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
                    editable={true}
                    durationEditable={true}
                    eventDurationEditable={true}
                    eventResizableFromStart={true}
                    eventResourceEditable={true}
                    defaultView="dayGridMonth"
                    headerToolbar={{
                        left: "myPreviousButton, myNextButton",
                        center: "title",
                        right: "timeGridDay,timeGridWeek,dayGridMonth" //listWeek isn'r functioning . it does in: https://codesandbox.io/s/i5zsx?file=/src/DemoApp.jsx:1453-1465
                    }}
                    customButtons={{
                        myPreviousButton: {
                            text: "<<",
                            click: function () {
                                let calendarApi = calendarRef.current.getApi();
                                calendarApi.prev();
                            }
                        },
                        myNextButton: {
                            text: ">>",
                            click: function () {
                                let calendarApi = calendarRef.current.getApi();
                                calendarApi.next();
                            }
                        }
                    }}
                    initialView="timeGridWeek"
                    weekends={true}
                    rerenderDelay={10}
                    ref={calendarRef}
                    eventDrop={handleDropEvent}
                    eventResizeStop={handleResizeEvent}
                    eventContent={renderEventContent} // custom render function
                />
            </div>
        </div>
    );
};

export default SaloonSchedule;

{/* In case of day & week - no need to add the time to the title. in case of month it is needed */ }