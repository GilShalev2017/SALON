function WeekSchedule() {
    return (
        <div>
            <h2>Welcome to WeekSchedule !!!</h2>
        </div>
    );
}

export default WeekSchedule;