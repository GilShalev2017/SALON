import React, { useState, useEffect } from "react";
import Axios from "axios";
import { Link } from 'react-router-dom';

//TODO style useing cards
function SearchCustomer() {
    const [customerPrefix, setCustomerPrefix] = useState('');
    const [customers, setCustomers] = useState([]);

    // useEffect(() => {
    //     fetchCustomers();
    // }, []);

    const fetchCustomers = () => {
        //Axios.get('https://jsonplaceholder.typicode.com/users').then(response => {
        Axios.get(`http://localhost:3000/findCustomer/${customerPrefix}`).then(response => {
            setCustomers(Array.from(response.data));
            console.log(customers);
        });
    };

    function onTextChanged(e) {
        let value = e.target.value;
        setCustomerPrefix(value);
    }

    return (
        <div style={{ textAlign: "center" }}>
            <input type="text" placeholder="Search a Customer" onChange={onTextChanged}></input>
            <button onClick={fetchCustomers}>Serach</button>
            <div>
                {
                    customers.map((customer) => (
                        <div key={customer._id} style={{ textAlign: "center" }}>
                            <div>Name: {customer.firstName} {customer.lastName}</div>
                            <div>Phone Number: {customer.phone}</div>
                            <div>Email: {customer.email}</div>
                            <div>Address: {customer.address}</div>
                            <div>
                                <Link to="/customer-ticket" state={{ from: customer }}>
                                    <button>Open Customer's Ticket</button>
                                </Link>
                            </div>
                        </div>
                    ))}
            </div>
        </div>
    );
}

export default SearchCustomer;