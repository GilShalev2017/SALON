import React, { useState, useEffect } from "react";
import Axios from "axios";
import { Link } from 'react-router-dom';

function AddNewCustomer() {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [address, setAddress] = useState('');
    const [birthdate, setBirthdate] = useState(0);

    const [newCustomer, setNewCustomer] = useState(null);

    function saveCustomer() {
        Axios.post('http://localhost:3000/add-customer',
            {
                firstName: firstName,
                lastName: lastName,
                phone: phone,
                email: email,
                birthDate: birthdate,
                address: address
            })
            .then(response => {
                console.log(response);
                setNewCustomer(response);
            })
            .catch(error => {
                console.log(error);
            })
    }

    return (
        <div>
            <h2>Weclcome to AddNewCustomer !!!</h2>
            <div style={{ textAlign: "center" }}>
                <div>
                    <img src="https://media-exp2.licdn.com/dms/image/C4D03AQHTLgbwEQjOhg/profile-displayphoto-shrink_100_100/0/1517457003952?e=1662595200&v=beta&t=bGIJZo80g_oPkMscF5M5LiGJXR9P00mx5C_ZdVMHtX4" />
                </div>
                <div>First Name: <input placeholder="Fill your first name" onChange={(e) => setFirstName(e.target.value)} /></div>
                <div>Last Name: <input placeholder="Fill your last name" onChange={(e) => setLastName(e.target.value)} /></div>
                <div>Phone Number: <input placeholder="Fill your phone number" onChange={(e) => setPhone(e.target.value)} /></div>
                <div>Email: <input placeholder="Fill your email" onChange={(e) => setEmail(e.target.value)} /></div>
                {/* <div>Address: City:<input placeholder="Fill the City" onChange={(e) => setUsername(e.target.value)} /> Street:<input placeholder="Fill the Street" />Suite:<input placeholder="Fill the suite number" /></div> */}
                <div>Address: <input placeholder="Fill you address" onChange={(e) => setAddress(e.target.value)} /></div>
                <div>Birthdate:<input placeholder="Fill the birthday" type="date" onChange={(e) => setBirthdate(e.target.value)} /></div>
                <div><button onClick={saveCustomer}>Save Customer Details</button></div>
                {/* Enable only if new customer has been saved */}
                <div>
                    {newCustomer && <Link to="/book-appointment" customer={newCustomer}>
                        <button>Book an appointment</button>
                    </Link>}
                </div>
            </div>
        </div>
    );
}

export default AddNewCustomer;