function About() {
    return (
        <div>
            <h2>Weclcome to About !!!</h2>
        </div>
    );
}

export default About;