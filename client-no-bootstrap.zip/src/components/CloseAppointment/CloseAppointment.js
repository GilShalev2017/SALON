function CloseAppointment() {
    return (
        <div>
            <h2>Weclcome to CloseAppointment !!!</h2>
            <div style={{ textAlign: "center" }}>
                <div>
                    <img src="https://media-exp2.licdn.com/dms/image/C4D03AQHTLgbwEQjOhg/profile-displayphoto-shrink_100_100/0/1517457003952?e=1662595200&v=beta&t=bGIJZo80g_oPkMscF5M5LiGJXR9P00mx5C_ZdVMHtX4" />
                </div>
                <div>Name: <input placeholder="Fill your name" /></div>
                <div>Phone Number: <input placeholder="Fill your phone number" /></div>
                <div>Email: <input placeholder="Fill your email" /></div>
                <div>Address: City:<input placeholder="Fill the City" /> Street:<input placeholder="Fill the Street" />Suite:<input placeholder="Fill the suite number" /></div>
                <div>Birthday:<input placeholder="Fill the birthday" type="date" /></div>
                <div><button>Save Customer Details</button></div>
            </div>
        </div>
    );
}

export default CloseAppointment;