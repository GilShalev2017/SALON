import React, { useState, useEffect } from "react";
import Axios from "axios";

function CustomerTreatments(props) {
    const [id, setId] = useState(props.customer._id);
    const [firstName, setFirstName] = useState(props.customer.firstName);
    const [lastName, setLastName] = useState(props.customer.lastName);

    const [treatments, setTreatments] = useState([]);
    const [openedAppointments, setOpenedAppointments] = useState([]);

    useEffect(() => {
        fetchCustomerTreatments();
        fetchCustomerOpenedAppointments();
    }, []);


    const fetchCustomerTreatments = () => {
        Axios.get('https://jsonplaceholder.typicode.com/users').then(response => {
            setTreatments(Array.from(response.data));
            console.log(treatments);
        });
    };

    const fetchCustomerOpenedAppointments = () => {

        Axios.post('http://localhost:3000/get-opened-appointments',
            {
                customerId: id
            })
            .then(response => {
                setOpenedAppointments(Array.from(response.data));
                console.log(openedAppointments);
            })
            .catch(error => {
                console.log(error);
            })

        Axios.get('http://localhost:3000/todays-appointments')
            .then(response => {
                const todays = (Array.from(response.data));
                console.log(todays);
            })
            .catch(error => {
                console.log(error);
            })

        // Axios.post('http://localhost:3000/get-customer-appointments',
        //     {
        //         customerId: id
        //     })
        //     .then(response => {
        //         const all = (Array.from(response.data));
        //         console.log(all);
        //     })
        //     .catch(error => {
        //         console.log(error);
        //     })
    };

    function addTreatment() {
        Axios.post('http://localhost:3000/add-treatment',
            {
                customerId: id,
                firstName: firstName,
                lastName: lastName,
                date: "05-05-2025",
                treatment: 'coloring and dying'
            })
            .then(response => {
                console.log(response);
                //addTreatment(response);
            })
            .catch(error => {
                console.log(error);
            })
    }

    return (
        <div style={{ textAlign: "center" }}>
            {/* <h2>Welcome to CustomerTreatments</h2> */}
            <table style={{ textAlign: "center", margin: "auto" }}>
                <thead style={{ textAlign: "center" }}>
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Time</th>
                        <th scope="col">Customer Name</th>
                        <th scope="col">Treatment</th>
                    </tr>
                </thead>
                <tbody style={{ textAlign: "center" }}>
                    {treatments.map((treatment) => (
                        <tr key={treatment.id}>
                            {/* <th>{treatment.customerName}</th>
                            <th>{treatment.treatmentDate}</th>
                            <th>{treatment.treatmentTime}</th> */}
                            <th>{treatment.name}</th>
                            <th>"07-09-2022"</th>
                            <th>"20:00"</th>
                            <th>"Color"</th>
                        </tr>
                    ))}
                </tbody>
            </table>
            <button onClick={addTreatment}>Add Treatment</button>
            {openedAppointments.map((openedApp) => (
                <div key={openedApp._id}>
                    Date: {openedApp.dateString}-{openedApp.timeString} Treatment:{openedApp.treatment}
                </div>
            ))}
        </div>
    );
}

export default CustomerTreatments;