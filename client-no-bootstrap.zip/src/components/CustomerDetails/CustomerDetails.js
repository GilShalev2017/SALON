import { useState } from 'react';
import CustomerTreatments from '../CustomerTreatments/CustomerTreatments';
import EditCustomer from '../EditCustomer/EditCustomer';
function CustomerDetails(props) {
    // const location = useLocation();
    // const { from } = location?.state;
    const [isEdit, setIsEdit] = useState(false);

    function editCustomer() {
        setIsEdit(true);
    }

    function finishEditing() {
        setIsEdit(false);
    }

    console.log(props);
    return (
        <div style={{ textAlign: "center" }}>
            <div>
                <img src="https://media-exp2.licdn.com/dms/image/C4D03AQFj_SndujH84g/profile-displayphoto-shrink_100_100/0/1517472957222?e=1662595200&v=beta&t=24gEoeCnx45qivlFCy5zrHIEujXMBEESMduOl3kN-hE" />
            </div>
            {!isEdit &&
                <div>
                    <div>Name: {props.customer.firstName} {props.customer.lastName}</div>
                    <div>Phone Number: {props.customer.phone}</div>
                    <div>Email: {props.customer.email}</div>
                    <div>Address: {props.customer.address}</div>
                    <button onClick={editCustomer}>Edit</button>
                </div>
            }
            {isEdit && <EditCustomer customer={props.customer} editcallback={finishEditing} />}
            {<CustomerTreatments customer={props.customer} />}
        </div>
    );
}

export default CustomerDetails;