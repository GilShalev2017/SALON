import Calendar from "react-calendar";
import React, { useState, useEffect } from "react";
import Axios from "axios";
import { useLocation } from 'react-router-dom'


function BookAppointment(props) {

    function getCurrentDate() {
        const date = new Date()
        let currDate = date.getFullYear().toString()
        const month = date.getMonth() + 1
        const day = date.getDate()
        currDate += month < 10 ? ('-0' + month.toString()) : '-' + month.toString()
        currDate += day < 10 ? ('-0' + day.toString()) : '-' + day.toString()
        return currDate;
    }

    function getCurrentTime() {
        let date = new Date();
        
        //TODO find if it's needed
        const TIMEOFFSET = '+05:30'

        let hour = date.getHours();
        if (hour < 10) {
            hour = `0${hour}`;
        }
        let minute = date.getMinutes();
        if (minute < 10) {
            minute = `0${minute}`;
        }

        const currentTime = `${hour}:${minute}:00.000${TIMEOFFSET}`;
        return currentTime;
    }

    const [treatment, setTreatment] = useState('Color');

    //console.log(props.customer);
    const location = useLocation();
    const { from } = location?.state;
    console.log(from);

    function handleTreatmentSelected(e) {
        setTreatment(e.target.value)
    }

    function book() {

        const currDate = getCurrentDate();
        const currentTime = getCurrentTime();

        Axios.post('http://localhost:3000/add-appointment',
            {
                customerId: from._id,
                firstName: from.firstName,
                lastName: from.lastName,
                date: new Date(),
                dateString: currDate,
                timeString: currentTime,//new Date().toLocaleTimeString(),
                treatment: treatment,
                status: "Open"
            })
            .then(response => {
                console.log(response);
                //setNewBook(response);
            })
            .catch(error => {
                console.log(error);
            })
    }

    return (
        <div>
            <h2>Weclcome to BookAppointment !!!</h2>
            <div>Name: {from.firstName} {from.lastName}</div>
            <span>Treatment Type:</span>
            <select name="treatments" id="treatments" value="{treatment}" onChange={handleTreatmentSelected}>
                <option value="Cut">Cut</option>
                <option value="Color">Color</option>
                <option value="HairDress">HairDress</option>
                <option value="Beard">Beard</option>
            </select>
            <Calendar />
            <button onClick={book}>Book</button>
        </div>
    );
}

export default BookAppointment;