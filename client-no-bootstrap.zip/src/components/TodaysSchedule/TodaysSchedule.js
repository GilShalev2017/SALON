import React, { useState, useEffect } from "react";
import Axios from "axios";

function TodaysSchedule() {
    const [todaysAppointments, setTodaysAppointments] = useState([]);

    useEffect(() => {
        fetchTodaysSchedule();
    }, []);

    const fetchTodaysSchedule = () => {
        Axios.get('http://localhost:3000/todays-appointments')
            .then(response => {
                setTodaysAppointments(Array.from(response.data));
                console.log(todaysAppointments);
            })
            .catch(error => {
                console.log(error);
            })
    };

    return (
        <div>
            <h2>Welcome to TodaysSchedule !!!</h2>
            {todaysAppointments.map((appointment) => (
                <div key={appointment._id}>
                    Customer: {appointment.firstName} {appointment.lastName}--Time:{appointment.timeString} - {appointment.treatment}
                </div>
            ))}
        </div>
    );
}

export default TodaysSchedule;