import React, { useState, useEffect } from "react";
import Axios from "axios";
import { Link } from 'react-router-dom';

function EditCustomer(props) {
    console.log(props);
    const [id, setId] = useState(props.customer._id);
    const [firstName, setFirstName] = useState(props.customer.firstName);
    const [lastName, setLastName] = useState(props.customer.lastName);
    const [phone, setPhone] = useState(props.customer.phone);
    const [email, setEmail] = useState(props.customer.email);
    const [address, setAddress] = useState(props.customer.address);
    const [birthdate, setBirthdate] = useState(props.customer.birthdate);

    function updateCustomer() {
        Axios.put('http://localhost:3000/update-customer',
            {
                _id: id,
                firstName: firstName,
                lastName: lastName,
                phone: phone,
                email: email,
                birthDate: birthdate,
                address: address
            })
            .then(response => {
                console.log(response);
                props.editcallback();
            })
            .catch(error => {
                console.log(error);
                props.editcallback();
            });
    }

    return (
        <div>
            <div style={{ textAlign: "center" }}>
                {/* <div>
                    <img src="https://media-exp2.licdn.com/dms/image/C4D03AQHTLgbwEQjOhg/profile-displayphoto-shrink_100_100/0/1517457003952?e=1662595200&v=beta&t=bGIJZo80g_oPkMscF5M5LiGJXR9P00mx5C_ZdVMHtX4" />
                </div> */}
                <div>First Name: <input value={firstName} onChange={(e) => setFirstName(e.target.value)} /></div>
                <div>Last Name: <input value={lastName} onChange={(e) => setLastName(e.target.value)} /></div>
                <div>Phone Number: <input value={phone} onChange={(e) => setPhone(e.target.value)} /></div>
                <div>Email: <input value={email} onChange={(e) => setEmail(e.target.value)} /></div>
                {/* <div>Address: City:<input placeholder="Fill the City" onChange={(e) => setUsername(e.target.value)} /> Street:<input placeholder="Fill the Street" />Suite:<input placeholder="Fill the suite number" /></div> */}
                <div>Address: <input value={address} onChange={(e) => setAddress(e.target.value)} /></div>
                <div>Birthdate:<input value={birthdate} type="date" onChange={(e) => setBirthdate(e.target.value)} /></div>
                <div>
                    <button onClick={updateCustomer}>Update Customer</button>
                </div>
            </div>
        </div>
    );
}

export default EditCustomer;