import { useLocation } from 'react-router-dom'
import CustomerDetails from '../CustomerDetails/CustomerDetails';
import { Link } from 'react-router-dom';

function CustomerTicket(props) {
    const location = useLocation();
    const { from } = location?.state;
    console.log(from);
    return (
        <div style={{ textAlign: "center" }}>
            <h2>Customer '{from.firstName} {from.lastName}' - Details and Treatments </h2>
            <CustomerDetails customer={from} />
            <div>
                <Link to="/book-appointment" state={{ from: from }}>
                    <button>Book an appointment</button>
                </Link>
            </div>

        </div>
    );
}

export default CustomerTicket;