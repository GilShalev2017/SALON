import './App.css';
import SearchCustomer from './components/SearchCustomer/SearchCustomer';
import BookAppointment from './components/BookAppointment/BookAppointment';
import AddNewCustomer from './components/AddNewCustomer/AddNewCustomer';
import CloseAppointment from './components/CloseAppointment/CloseAppointment';
import CustomerDetails from './components/CustomerDetails/CustomerDetails';
import CustomerTicket from './components/CustomerTicket/CustomerTicket';
import TodaysSchedule from './components/TodaysSchedule/TodaysSchedule';
import WeekSchedule from './components/WeekSchedule/WeekSchedule';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';


function App() {
  return (
    <div className="wrapper">
      <h1>What would you like to Do?</h1>
      <nav>
        <ul>
          <li><a href="/search-customer">Search a Customer</a></li>
          <li><a href="/add-new-customer">Add a new Customer</a></li>
          {/* <li><a href="/book-appointment">Book an Appointment</a></li> */}
          {/* <li><a href="/close-appointment">Close an appointment</a></li> */}
          <li><a href="/todays-schedule">Watch Today's Appointments</a></li>
          <li><a href="/week-schedule">Watch This Week's Schedule</a></li>
          <li><a href="/salon-treatments">Salon's Treatments and Tarif</a></li>
        </ul>
      </nav>
      <BrowserRouter>
        <Routes>
          {/* <Route path="/" element={<SearchCustomer/>}></Route> */}
          <Route path="/search-customer" element={<SearchCustomer/>}></Route>
          <Route path="/book-appointment" element={<BookAppointment/>}></Route>
          <Route path="/customer-details" element={<CustomerDetails/>}></Route>
          <Route path="/add-new-customer" element={<AddNewCustomer/>}></Route>
          <Route path="/customer-ticket" element={<CustomerTicket/>}></Route>
          <Route path="/close-appointment" element={<CloseAppointment/>}></Route>
          <Route path="/todays-schedule" element={<TodaysSchedule/>}></Route>
          <Route path="/week-schedule" element={<WeekSchedule/>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
